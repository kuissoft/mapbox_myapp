(function() {
	'use strict';
  var mainApp = angular.module('mainApp');
});